

public class Doctor implements Runnable {
	String group;
	Doctor(String group)
	{
		this.group=group;
	}
	
	public void run() {
		System.out.println("test");
		
		}


}
